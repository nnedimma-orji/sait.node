const {error}= require("console");
const express= require("express");
const app= express();
const path= require("path");
app.listen(8000, (err)=>{
    if (err) throw err;
    console.log("server started on port 8000");
});

app.use(express.static(path.join(__dirname,"views"), {extensions:["html", "htm"]}));
app.use(express.static(path.join(__dirname,"media"), {extensions:["gif", "jpg", "png"]}));
app.use(express.static(path.join(__dirname,"public"), {extensions:["css", "js"]}));
app.use(express.urlencoded({extended:true}));

app.get("/",(req, res)=>{
    res.render("create-post");
});
app.post("/create-post", (req,res)=>{
    console.log("perfect!");
    var mypost = req.body.blogpost;
   // res.send("<h1 style= 'backgroundcolor: aqua';>message recieved:"+ mypost + "</h1>");
    res.redirect("/Thank-you");
});
//look up digital ocean and install Pug 