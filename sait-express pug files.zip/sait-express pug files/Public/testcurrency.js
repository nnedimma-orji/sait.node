const currency= require ("./currency");
console.log (`50 canadian Dollars=${currency.canadianToUS(50)}US dollars.`);
console.log (`50 US Dollars=${currency.USToCanadian(50)} Canadian dollars.`);